Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - SpeedY ( https://freesound.org/people/SpeedY/ )

You can find this pack online at: https://freesound.org/people/SpeedY/packs/469/

License details
---------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 8403__SpeedY__Clean_G_str_pluck.wav
    * url: https://freesound.org/s/8403/
    * license: Creative Commons 0
  * 8402__SpeedY__Clean_G_str_pick.wav
    * url: https://freesound.org/s/8402/
    * license: Creative Commons 0
  * 8401__SpeedY__Clean_G_harm1.wav
    * url: https://freesound.org/s/8401/
    * license: Creative Commons 0
  * 8400__SpeedY__Clean_G_harm.wav
    * url: https://freesound.org/s/8400/
    * license: Creative Commons 0
  * 8399__SpeedY__Clean_Finger_slide_delay.wav
    * url: https://freesound.org/s/8399/
    * license: Creative Commons 0
  * 8398__SpeedY__Clean_Finger_slide2_delay.wav
    * url: https://freesound.org/s/8398/
    * license: Creative Commons 0
  * 8397__SpeedY__Clean_E_str_pluck.wav
    * url: https://freesound.org/s/8397/
    * license: Creative Commons 0
  * 8396__SpeedY__Clean_E_str_pick.wav
    * url: https://freesound.org/s/8396/
    * license: Creative Commons 0
  * 8395__SpeedY__Clean_E_harm.wav
    * url: https://freesound.org/s/8395/
    * license: Creative Commons 0
  * 8394__SpeedY__Clean_E1st_str_pluck.wav
    * url: https://freesound.org/s/8394/
    * license: Creative Commons 0
  * 8393__SpeedY__Clean_E1st_str_pick.wav
    * url: https://freesound.org/s/8393/
    * license: Creative Commons 0
  * 8392__SpeedY__Clean_E1st_harm.wav
    * url: https://freesound.org/s/8392/
    * license: Creative Commons 0
  * 8391__SpeedY__Clean_E1st_5th.wav
    * url: https://freesound.org/s/8391/
    * license: Creative Commons 0
  * 8390__SpeedY__Clean_E1st_12th.wav
    * url: https://freesound.org/s/8390/
    * license: Creative Commons 0
  * 8389__SpeedY__Clean_D_str_pluck.wav
    * url: https://freesound.org/s/8389/
    * license: Creative Commons 0
  * 8388__SpeedY__Clean_D_str_pick.wav
    * url: https://freesound.org/s/8388/
    * license: Creative Commons 0
  * 8387__SpeedY__Clean_D_harm.wav
    * url: https://freesound.org/s/8387/
    * license: Creative Commons 0
  * 8386__SpeedY__Clean_B_str_pluck.wav
    * url: https://freesound.org/s/8386/
    * license: Creative Commons 0
  * 8385__SpeedY__Clean_B_str_pick.wav
    * url: https://freesound.org/s/8385/
    * license: Creative Commons 0
  * 8384__SpeedY__Clean_B_harm.wav
    * url: https://freesound.org/s/8384/
    * license: Creative Commons 0
  * 8383__SpeedY__Clean_A_str_pluck.wav
    * url: https://freesound.org/s/8383/
    * license: Creative Commons 0
  * 8382__SpeedY__Clean_A_str_pick.wav
    * url: https://freesound.org/s/8382/
    * license: Creative Commons 0
  * 8381__SpeedY__Clean_A_harm.wav
    * url: https://freesound.org/s/8381/
    * license: Creative Commons 0


